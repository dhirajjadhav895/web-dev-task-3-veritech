document.addEventListener('DOMContentLoaded', () => {
    const taskInput = document.getElementById('new-task');
    const addTaskBtn = document.getElementById('add-task-btn');
    const taskList = document.getElementById('task-list');

    const loadTasks = () => {
        const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
        tasks.forEach(task => addTaskToDOM(task));
    };

    const saveTasks = tasks => {
        localStorage.setItem('tasks', JSON.stringify(tasks));
    };

    const getTasks = () => {
        return JSON.parse(localStorage.getItem('tasks')) || [];
    };

    const addTaskToDOM = (task) => {
        const li = document.createElement('li');
        li.className = `task ${task.completed ? 'completed' : ''}`;
        li.innerHTML = `
            <span>${task.text}</span>
            <div>
                <button onclick="editTask('${task.text}')">Edit</button>
                <button onclick="deleteTask('${task.text}')">Delete</button>
                <button onclick="toggleComplete('${task.text}')">${task.completed ? 'Undo' : 'Complete'}</button>
            </div>
        `;
        taskList.appendChild(li);
    };

    const addTask = () => {
        const taskText = taskInput.value.trim();
        if (taskText) {
            const tasks = getTasks();
            const newTask = { text: taskText, completed: false };
            tasks.push(newTask);
            saveTasks(tasks);
            addTaskToDOM(newTask);
            taskInput.value = '';
        }
    };

    const editTask = (taskText) => {
        const tasks = getTasks();
        const task = tasks.find(t => t.text === taskText);
        if (task) {
            const newTaskText = prompt('Edit Task:', task.text);
            if (newTaskText) {
                task.text = newTaskText;
                saveTasks(tasks);
                renderTasks();
            }
        }
    };

    const deleteTask = (taskText) => {
        let tasks = getTasks();
        tasks = tasks.filter(t => t.text !== taskText);
        saveTasks(tasks);
        renderTasks();
    };

    const toggleComplete = (taskText) => {
        const tasks = getTasks();
        const task = tasks.find(t => t.text === taskText);
        if (task) {
            task.completed = !task.completed;
            saveTasks(tasks);
            renderTasks();
        }
    };

    const renderTasks = () => {
        taskList.innerHTML = '';
        loadTasks();
    };

    addTaskBtn.addEventListener('click', addTask);
    loadTasks();
});

function editTask(taskText) {
    document.querySelector(`button[onclick="editTask('${taskText}')"]`).click();
}

function deleteTask(taskText) {
    document.querySelector(`button[onclick="deleteTask('${taskText}')"]`).click();
}

function toggleComplete(taskText) {
    document.querySelector(`button[onclick="toggleComplete('${taskText}')"]`).click();
}
